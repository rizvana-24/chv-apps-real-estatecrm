# Real Estate CRM Node.js + MongoDB Backend

This backend covers the data shown in the uploaded CRM frontend.

## Main modules
- Authentication: super-admin, admin, agent, customer
- Users / admins / agents / customers
- Properties
- Leads and pipeline
- Appointments
- Enquiries
- Favorites
- Site visits
- Customer-agent chat/messages
- Dashboard and performance reports

## Setup

1. Install Node.js 20+.
2. Install MongoDB locally, or create a MongoDB Atlas database.
3. Copy `.env.example` to `.env` and set `MONGO_URI` and `JWT_SECRET`.
4. Run:

```bash
npm install
npm run seed
npm run dev
```

API starts at `http://localhost:5000`.

## Authentication

Login:

`POST /api/auth/login`

Body:
```json
{
  "email": "superadmin@chvapps.com",
  "password": "Password@123"
}
```

Send the returned token on protected requests:

`Authorization: Bearer <token>`

## API endpoints

### Auth
- POST `/api/auth/register`
- POST `/api/auth/login`
- GET `/api/auth/me`

### Users
- GET `/api/users`
- GET `/api/users/:id`
- POST `/api/users`
- PATCH `/api/users/:id`
- DELETE `/api/users/:id`

### Properties
- GET `/api/properties`
- GET `/api/properties/public/search`
- GET `/api/properties/:id`
- POST `/api/properties`
- PATCH `/api/properties/:id`
- DELETE `/api/properties/:id`

### Leads
- GET `/api/leads`
- GET `/api/leads/:id`
- POST `/api/leads`
- PATCH `/api/leads/:id`
- DELETE `/api/leads/:id`

### Appointments
- GET `/api/appointments`
- GET `/api/appointments/:id`
- POST `/api/appointments`
- PATCH `/api/appointments/:id`
- DELETE `/api/appointments/:id`

### Enquiries
- GET `/api/enquiries`
- GET `/api/enquiries/:id`
- POST `/api/enquiries`
- PATCH `/api/enquiries/:id`
- DELETE `/api/enquiries/:id`

### Favorites
- GET `/api/favorites`
- POST `/api/favorites/:propertyId`
- DELETE `/api/favorites/:propertyId`

### Site visits
- GET `/api/site-visits`
- GET `/api/site-visits/:id`
- POST `/api/site-visits`
- PATCH `/api/site-visits/:id`
- DELETE `/api/site-visits/:id`

### Messages
- GET `/api/messages`
- GET `/api/messages?withUser=<userId>`
- POST `/api/messages`
- PATCH `/api/messages/:id/read`

### Reports
- GET `/api/reports/dashboard`
- GET `/api/reports/lead-pipeline`
- GET `/api/reports/agent-performance`
- GET `/api/reports/system`

## Frontend connection

Your React/TanStack frontend can call this backend with:

```ts
const API = "http://localhost:5000/api";

const response = await fetch(`${API}/properties`, {
  headers: {
    Authorization: `Bearer ${localStorage.getItem("token")}`
  }
});

const data = await response.json();
```

Do not keep the frontend's hard-coded arrays once API integration is complete; replace them with API calls.
