import express from "express";
import cors from "cors";
import morgan from "morgan";
import { config } from "./config.js";
import { connectDB } from "./db.js";
import api from "./routes/index.js";

const app = express();

app.use(cors({ origin: config.clientUrl, credentials: true }));
app.use(express.json({ limit: "2mb" }));
app.use(express.urlencoded({ extended: true }));
app.use(morgan("dev"));

app.get("/api/health", (req, res) => res.json({ ok: true, service: "real-estate-crm-api" }));
app.use("/api", api);

app.use((err, req, res, next) => {
  console.error(err);
  if (err.code === 11000) return res.status(409).json({ message: "Duplicate value", details: err.keyValue });
  res.status(err.status || 500).json({ message: err.message || "Internal server error" });
});

connectDB()
  .then(() => app.listen(config.port, () => console.log(`API running on http://localhost:${config.port}`)))
  .catch((err) => { console.error("DB connection failed", err); process.exit(1); });