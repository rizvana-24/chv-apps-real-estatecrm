import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import User from "../models/User.js";
import { config } from "../config.js";

function tokenFor(user) {
  return jwt.sign({ id: user._id, role: user.role }, config.jwtSecret, { expiresIn: "7d" });
}

export async function register(req, res) {
  const { name, email, password, role = "customer", phone, region } = req.body;
  if (!name || !email || !password) return res.status(400).json({ message: "name, email and password are required" });
  if (!["customer", "agent"].includes(role)) return res.status(400).json({ message: "Public registration is only for customer/agent" });

  const exists = await User.findOne({ email });
  if (exists) return res.status(409).json({ message: "Email already registered" });

  const hash = await bcrypt.hash(password, 12);
  const user = await User.create({ name, email, password: hash, role, phone, region, status: role === "agent" ? "Pending KYC" : "Verified" });
  res.status(201).json({ token: tokenFor(user), user: user.toJSON() });
}

export async function login(req, res) {
  const { email, password } = req.body;
  const user = await User.findOne({ email }).select("+password");
  if (!user || !(await bcrypt.compare(password, user.password))) return res.status(401).json({ message: "Invalid email or password" });
  if (["Blocked", "Suspended"].includes(user.status)) return res.status(403).json({ message: "Account is blocked/suspended" });

  user.lastSeen = new Date();
  await user.save();
  const safe = user.toObject();
  delete safe.password;
  res.json({ token: tokenFor(user), user: safe });
}

export async function me(req, res) {
  res.json({ user: req.user });
}