export function makeCrud(Model, options = {}) {
  const populate = options.populate || "";
  return {
    list: async (req, res) => {
      const filter = { ...(options.baseFilter ? options.baseFilter(req) : {}) };
      if (req.query.status) filter.status = req.query.status;
      if (req.query.search) {
        const rx = new RegExp(req.query.search, "i");
        filter.$or = [{ name: rx }, { code: rx }, { city: rx }, { locality: rx }, { email: rx }];
      }
      const page = Math.max(Number(req.query.page || 1), 1);
      const limit = Math.min(Math.max(Number(req.query.limit || 20), 1), 100);
      const [items, total] = await Promise.all([
        Model.find(filter).populate(populate).sort({ createdAt: -1 }).skip((page - 1) * limit).limit(limit),
        Model.countDocuments(filter)
      ]);
      res.json({ items, pagination: { page, limit, total, pages: Math.ceil(total / limit) } });
    },
    get: async (req, res) => {
      const item = await Model.findById(req.params.id).populate(populate);
      if (!item) return res.status(404).json({ message: "Not found" });
      res.json(item);
    },
    create: async (req, res) => {
      const item = await Model.create(req.body);
      res.status(201).json(item);
    },
    update: async (req, res) => {
      const item = await Model.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true }).populate(populate);
      if (!item) return res.status(404).json({ message: "Not found" });
      res.json(item);
    },
    remove: async (req, res) => {
      const item = await Model.findByIdAndDelete(req.params.id);
      if (!item) return res.status(404).json({ message: "Not found" });
      res.json({ message: "Deleted successfully", id: item._id });
    }
  };
}