import SiteVisit from "../models/SiteVisit.js";
import { crudRoutes } from "./crud.js";
export default crudRoutes(SiteVisit, { populate: "customer agent property" });