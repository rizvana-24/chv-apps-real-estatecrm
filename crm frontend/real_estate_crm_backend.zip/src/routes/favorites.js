import { Router } from "express";
import Favorite from "../models/Favorite.js";
import { auth } from "../middleware/auth.js";

const router = Router();
router.get("/", auth, async (req, res) => {
  const items = await Favorite.find({ customer: req.user._id }).populate("property");
  res.json(items);
});
router.post("/:propertyId", auth, async (req, res) => {
  const item = await Favorite.findOneAndUpdate(
    { customer: req.user._id, property: req.params.propertyId },
    { customer: req.user._id, property: req.params.propertyId, note: req.body.note },
    { upsert: true, new: true, setDefaultsOnInsert: true }
  ).populate("property");
  res.status(201).json(item);
});
router.delete("/:propertyId", auth, async (req, res) => {
  await Favorite.findOneAndDelete({ customer: req.user._id, property: req.params.propertyId });
  res.json({ message: "Removed from favorites" });
});
export default router;