import Enquiry from "../models/Enquiry.js";
import { crudRoutes } from "./crud.js";
export default crudRoutes(Enquiry, { populate: "customer agent property" });