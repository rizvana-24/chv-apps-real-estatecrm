import { Router } from "express";
import auth from "./auth.js";
import users from "./users.js";
import properties from "./properties.js";
import leads from "./leads.js";
import appointments from "./appointments.js";
import enquiries from "./enquiries.js";
import favorites from "./favorites.js";
import siteVisits from "./siteVisits.js";
import messages from "./messages.js";
import reports from "./reports.js";

const router = Router();

router.use("/auth", auth);
router.use("/users", users);
router.use("/properties", properties);
router.use("/leads", leads);
router.use("/appointments", appointments);
router.use("/enquiries", enquiries);
router.use("/favorites", favorites);
router.use("/site-visits", siteVisits);
router.use("/messages", messages);
router.use("/reports", reports);

export default router;