import { Router } from "express";
import Message from "../models/Chat.js";
import { auth } from "../middleware/auth.js";

const router = Router();

router.get("/", auth, async (req, res) => {
  const filter = { $or: [{ sender: req.user._id }, { receiver: req.user._id }] };
  if (req.query.withUser) {
    filter.$and = [{
      $or: [
        { sender: req.user._id, receiver: req.query.withUser },
        { sender: req.query.withUser, receiver: req.user._id }
      ]
    }];
    delete filter.$or;
  }
  const items = await Message.find(filter).populate("sender receiver property").sort({ createdAt: 1 });
  res.json(items);
});

router.post("/", auth, async (req, res) => {
  const { receiver, text, property } = req.body;
  if (!receiver || !text) return res.status(400).json({ message: "receiver and text are required" });
  const item = await Message.create({ sender: req.user._id, receiver, text, property });
  res.status(201).json(await item.populate("sender receiver property"));
});

router.patch("/:id/read", auth, async (req, res) => {
  const item = await Message.findOneAndUpdate(
    { _id: req.params.id, receiver: req.user._id },
    { read: true },
    { new: true }
  );
  if (!item) return res.status(404).json({ message: "Message not found" });
  res.json(item);
});

export default router;