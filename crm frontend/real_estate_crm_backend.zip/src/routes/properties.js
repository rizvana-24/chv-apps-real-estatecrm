import { Router } from "express";
import Property from "../models/Property.js";
import { crudRoutes } from "./crud.js";
import { auth } from "../middleware/auth.js";

const router = crudRoutes(Property, { populate: "agent", });

router.get("/public/search", async (req, res) => {
  const { city, minPrice, maxPrice, type, status } = req.query;
  const filter = {};
  if (city) filter.$or = [{ city: new RegExp(city, "i") }, { locality: new RegExp(city, "i") }];
  if (minPrice || maxPrice) filter.price = { ...(minPrice ? { $gte: Number(minPrice) } : {}), ...(maxPrice ? { $lte: Number(maxPrice) } : {}) };
  if (type) filter.type = type;
  if (status) filter.status = status;
  const items = await Property.find(filter).populate("agent").sort({ createdAt: -1 });
  res.json(items);
});

export default router;