import Lead from "../models/Lead.js";
import { crudRoutes } from "./crud.js";
export default crudRoutes(Lead, { populate: "owner customer property" });