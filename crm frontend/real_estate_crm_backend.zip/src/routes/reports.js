import { Router } from "express";
import { auth, allow } from "../middleware/auth.js";
import User from "../models/User.js";
import Property from "../models/Property.js";
import Lead from "../models/Lead.js";
import Appointment from "../models/Appointment.js";
import Enquiry from "../models/Enquiry.js";
import SiteVisit from "../models/SiteVisit.js";

const router = Router();

router.get("/dashboard", auth, allow("super-admin", "admin", "agent"), async (req, res) => {
  const [users, agents, customers, properties, leads, appointments, enquiries, visits] = await Promise.all([
    User.countDocuments(),
    User.countDocuments({ role: "agent" }),
    User.countDocuments({ role: "customer" }),
    Property.countDocuments(),
    Lead.countDocuments({ stage: { $nin: ["Won", "Lost"] } }),
    Appointment.countDocuments(),
    Enquiry.countDocuments(),
    SiteVisit.countDocuments()
  ]);
  res.json({ users, agents, customers, properties, openLeads: leads, appointments, enquiries, siteVisits: visits });
});

router.get("/lead-pipeline", auth, allow("super-admin", "admin", "agent"), async (req, res) => {
  const rows = await Lead.aggregate([{ $group: { _id: "$stage", count: { $sum: 1 } } }, { $sort: { count: -1 } }]);
  res.json(rows);
});

router.get("/agent-performance", auth, allow("super-admin", "admin"), async (req, res) => {
  const rows = await Lead.aggregate([
    { $match: { owner: { $ne: null } } },
    { $group: { _id: "$owner", leads: { $sum: 1 }, won: { $sum: { $cond: [{ $eq: ["$stage", "Won"] }, 1, 0] } }, avgScore: { $avg: "$score" } } },
    { $lookup: { from: "users", localField: "_id", foreignField: "_id", as: "agent" } },
    { $unwind: "$agent" },
    { $project: { agent: "$agent.name", leads: 1, won: 1, avgScore: 1, conversion: { $cond: [{ $gt: ["$leads", 0] }, { $multiply: [{ $divide: ["$won", "$leads"] }, 100] }, 0] } } }
  ]);
  res.json(rows);
});

router.get("/system", auth, allow("super-admin"), async (req, res) => {
  res.json({
    generatedAt: new Date(),
    collections: {
      users: await User.countDocuments(),
      properties: await Property.countDocuments(),
      leads: await Lead.countDocuments(),
      appointments: await Appointment.countDocuments(),
      enquiries: await Enquiry.countDocuments(),
      siteVisits: await SiteVisit.countDocuments()
    }
  });
});

export default router;