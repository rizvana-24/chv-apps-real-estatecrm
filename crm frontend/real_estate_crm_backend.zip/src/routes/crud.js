import { Router } from "express";
import { makeCrud } from "../controllers/crudController.js";
import { auth } from "../middleware/auth.js";

export function crudRoutes(Model, options = {}) {
  const router = Router();
  const c = makeCrud(Model, options);
  router.get("/", auth, c.list);
  router.get("/:id", auth, c.get);
  router.post("/", auth, c.create);
  router.patch("/:id", auth, c.update);
  router.delete("/:id", auth, c.remove);
  return router;
}