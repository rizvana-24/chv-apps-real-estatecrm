import { Router } from "express";
import bcrypt from "bcryptjs";
import User from "../models/User.js";
import { auth, allow } from "../middleware/auth.js";

const router = Router();

router.get("/", auth, allow("super-admin", "admin"), async (req, res) => {
  const filter = {};
  if (req.query.role) filter.role = req.query.role;
  if (req.query.status) filter.status = req.query.status;
  if (req.query.search) filter.$or = [{ name: new RegExp(req.query.search, "i") }, { email: new RegExp(req.query.search, "i") }];
  const users = await User.find(filter).select("-password").sort({ createdAt: -1 });
  res.json(users);
});

router.post("/", auth, allow("super-admin", "admin"), async (req, res) => {
  const { name, email, password, role, region, permissions, phone, status } = req.body;
  const hash = await bcrypt.hash(password || "ChangeMe123!", 12);
  const user = await User.create({ name, email, password: hash, role, region, permissions, phone, status });
  const safe = user.toObject(); delete safe.password;
  res.status(201).json(safe);
});

router.get("/:id", auth, allow("super-admin", "admin"), async (req, res) => {
  const user = await User.findById(req.params.id).select("-password");
  if (!user) return res.status(404).json({ message: "User not found" });
  res.json(user);
});

router.patch("/:id", auth, allow("super-admin", "admin"), async (req, res) => {
  const data = { ...req.body };
  if (data.password) data.password = await bcrypt.hash(data.password, 12);
  const user = await User.findByIdAndUpdate(req.params.id, data, { new: true, runValidators: true }).select("-password");
  if (!user) return res.status(404).json({ message: "User not found" });
  res.json(user);
});

router.delete("/:id", auth, allow("super-admin"), async (req, res) => {
  const user = await User.findByIdAndDelete(req.params.id);
  if (!user) return res.status(404).json({ message: "User not found" });
  res.json({ message: "User deleted" });
});

export default router;