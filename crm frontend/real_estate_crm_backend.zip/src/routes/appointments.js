import Appointment from "../models/Appointment.js";
import { crudRoutes } from "./crud.js";
export default crudRoutes(Appointment, { populate: "customer agent property" });