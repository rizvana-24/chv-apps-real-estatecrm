import mongoose from "mongoose";

const reportSchema = new mongoose.Schema({
  name: String,
  type: String,
  period: String,
  generatedBy: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
  data: mongoose.Schema.Types.Mixed
}, { timestamps: true });

export default mongoose.model("Report", reportSchema);